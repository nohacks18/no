A Pen created at CodePen.io. You can find this one at https://codepen.io/alexdevero/pen/vNRqLL.

 Spectre sign up form.